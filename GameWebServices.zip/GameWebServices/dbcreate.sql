CREATE TABLE "PlayerProgress" (
	"username"	TEXT NOT NULL UNIQUE,
	"name"	TEXT,
	"company"	TEXT,
	"date_joined"	TEXT,
	"current_lvl"	TEXT,
	"points"	INTEGER,
	"comp_rate"	REAL,
	"last_played"	TEXT,
	PRIMARY KEY("username")
)

CREATE TABLE "login" (
	"name"	TEXT NOT NULL,
	"email"	TEXT NOT NULL UNIQUE,
	"password"	INTEGER NOT NULL,
	PRIMARY KEY("email")
)